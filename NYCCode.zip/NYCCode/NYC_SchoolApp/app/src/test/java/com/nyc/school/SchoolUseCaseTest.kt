package com.nyc.school

import android.util.Log
import com.nyc.school.repository.datamodel.NYCSchool
import com.nyc.school.usecase.SchoolListingUseCase
import com.nyc.school.usecase.UseCase
import com.nyc.school.usecase.UseCaseRegistry
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.*
import org.mockito.MockitoAnnotations
import org.mockito.Mockito.`when`


/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class SchoolUseCaseTest {

    lateinit var usecase: SchoolListingUseCase
    lateinit var registery: UseCaseRegistry

    @Before
    fun setup() {
        registery = UseCaseRegistry
        usecase = SchoolListingUseCase
        MockitoAnnotations.openMocks(this)
    }

    @Test
    fun getSchooListTest() {
        assert(
            registery.dataRegistery.size == 1,
            { "registry is not maintaining proper instance count" })

        //verify the same instance is being used across for usecase
        val usecaseInstancetoTest = registery.dataRegistery[NYCSchool::class]
        assert(usecaseInstancetoTest === usecase, { "multiple references of usecases" })
    }
}