package com.nyc.school.ui.adapters

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.nyc.school.databinding.SchoolItemListBinding
import com.nyc.school.databinding.SchoolItemListRowViewBinding
import com.nyc.school.repository.datamodel.NYCSchool
import com.nyc.school.ui.SchoolDetailActivity
import com.nyc.school.ui.UiConstants

class SchoolAdapter(
    private val values: List<NYCSchool>
) : RecyclerView.Adapter<SchoolAdapter.ViewHolder>() {
    inner class ViewHolder(private val binding: SchoolItemListRowViewBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: NYCSchool) {
            with(binding) {
                this@ViewHolder.binding.schoolName.text = item.schoolName
                this@ViewHolder.binding.schoolDescription.text = item.overviewParagraph
                this@ViewHolder.binding.school = item
                this@ViewHolder.binding.click = ClickListener()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SchoolAdapter.ViewHolder {
        val binding = SchoolItemListRowViewBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SchoolAdapter.ViewHolder, position: Int) =
        holder.bind(values[position])

    override fun getItemCount(): Int = values.size


    class ClickListener {

        var mLastClickTime: Long = 0

        fun onClick(context: Context, school: NYCSchool) {
            if (SystemClock.elapsedRealtime() - mLastClickTime < 3000) {
                Log.d("School clicked", "debounding")
                return;
            } else {
                Log.d("School clicked", "fetching for school : " + school.schoolName)
                mLastClickTime = SystemClock.elapsedRealtime()

                context.startActivity(Intent(context, SchoolDetailActivity::class.java).apply {
                    putExtra(UiConstants.SCHOOOL_BUNDLE_KEY, school)
                })
            }
        }
    }

}