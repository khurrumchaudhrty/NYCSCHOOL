package com.nyc.school.repository

import android.util.Log
import com.google.gson.GsonBuilder
import com.nyc.school.repository.api.SchoolAPI
import com.nyc.school.repository.datamodel.*
import com.nyc.school.usecase.UseCaseRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.reflect.Type
import kotlin.reflect.KClass
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor


// base url for the repositories, this should be
// in some constant file but for now leaving it here
val baseURL: String
    get() = "https://data.cityofnewyork.us/resource/"

// ideally this would be persisted in repository and follow up network request would have been
// avoided but for sake of example holding data of last fetch in repository for now
var currentSchoolCollection: List<NYCSchool>? = null

// ideally this would be persisted in repository and follow up network request would have been
// avoided but for sake of example holding data of last fetch in repository for now
var lastFetchedSatResult: List<SchoolSAT>? = null

private fun schoolAPI(): SchoolAPI {

    val logging = HttpLoggingInterceptor()
    logging.level = HttpLoggingInterceptor.Level.BASIC

    val httpClient = OkHttpClient.Builder()
    httpClient.addInterceptor(logging)

    val gson = GsonBuilder()
        .setLenient()
        .disableHtmlEscaping()
        .create()

    val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl(baseURL)
        .addConverterFactory(GsonConverterFactory.create(gson))
        .client(httpClient.build())
        .build()

    return retrofit.create(SchoolAPI::class.java)
}

private val schoolCallback = object : Callback<List<NYCSchool>> {

    override fun onResponse(
        call: Call<List<NYCSchool>>,
        response: Response<List<NYCSchool>>
    ) {
        if (response.isSuccessful) {
            val baseResponse: List<NYCSchool>? = response.body()
            baseResponse?.let {
                if(it.isNotEmpty()){
                    baseResponse.apply {
                        currentSchoolCollection = this
                        notifyRegister(currentSchoolCollection!!)
                    }
                } else{
                    notifyRegister(listOf(NYCSchool())) //empty response from api
                }
            }


        } else {
            // LOG THE ERROR
            Log.d(SchoolRepository.toString(), response.errorBody().toString())
        }
    }

    override fun onFailure(p0: Call<List<NYCSchool>>, p1: Throwable) {
        p1.printStackTrace()
        // notify the UI that communication is
        // broken down tho could be many reasons but user can be notifies that try again
    }
}

private val schoolSATCallBack = object : Callback<List<SchoolSAT>> {
    override fun onResponse(call: Call<List<SchoolSAT>>, response: Response<List<SchoolSAT>>) {
        if (response.isSuccessful) {
            val baseResponse: List<SchoolSAT>? = response.body()

            baseResponse?.let {
                if(it.isNotEmpty()){
                    baseResponse.apply {
                        lastFetchedSatResult = (this as List<SchoolSAT>)
                        notifyRegister(lastFetchedSatResult!!)
                    }
                } else{ //API return empty response
                    notifyRegister(listOf(SchoolSAT())) // empty
                }
            }

        } else {
            // LOG THE ERROR
            Log.d(SchoolRepository.toString(), response.errorBody().toString())
        }
    }

    override fun onFailure(p0: Call<List<SchoolSAT>>, p1: Throwable) {
        p1.printStackTrace()
        // notify the UI that communication is
        // broken down tho could be many reasons but user can be notifies that try again
    }

}

object SchoolRepository {
    fun getSchoolList(offSetRequested: Number) { //todo use offset
        val schoolAPI: SchoolAPI = schoolAPI()
        val call: Call<List<NYCSchool>>? = schoolAPI.getSchoolList(limit = (10+ (10 * offSetRequested.toInt())), offset = offSetRequested )
        call?.enqueue(schoolCallback)
    }

    fun getSchoolSAT(dbn: String) {
        val schoolAPI: SchoolAPI = schoolAPI()
        val call: Call<List<SchoolSAT>>? = schoolAPI.getSATScoreList(dbn)
        call?.enqueue(schoolSATCallBack)
    }
}


private fun notifyRegister(clazz: List<SchoolData>) {
    UseCaseRegistry.notifyFor(clazz)
}
