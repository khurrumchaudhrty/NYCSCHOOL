package com.nyc.school.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.nyc.school.repository.datamodel.NYCSchool
import com.nyc.school.repository.datamodel.SchoolSAT
import com.nyc.school.usecase.SchoolDetailUseCase

class SchoolDetailViewModel: ViewModel() {
    private var schoolData: NYCSchool? = null
    private val mutableSATData: MutableLiveData<SchoolSAT> =  MutableLiveData<SchoolSAT>()

    private fun getSchool() : NYCSchool = schoolData!!
    fun getSATDetails(): MutableLiveData<SchoolSAT> = mutableSATData

    private fun updateSchoolDetail(incomingData: SchoolSAT){
        incomingData.apply {
            mutableSATData.value= incomingData
        }
    }

    fun getSchoolSATData(school: NYCSchool){
        schoolData = school
        SchoolDetailUseCase.getSAT(getSchool().dbn!!, ::updateSchoolDetail)
    }

}