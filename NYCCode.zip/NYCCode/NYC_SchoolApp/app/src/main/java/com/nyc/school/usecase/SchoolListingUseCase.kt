package com.nyc.school.usecase

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.nyc.school.repository.SchoolRepository
import com.nyc.school.repository.datamodel.NYCSchool
import com.nyc.school.repository.datamodel.SchoolData
import com.nyc.school.repository.datamodel.SchoolSAT
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async

object SchoolListingUseCase : UseCase {

    private var updateSchoolData: ((List<NYCSchool>) -> Unit)? = null

    init {
        UseCaseRegistry.add(this, NYCSchool::class)
    }

    /**
     * UpdateLive Data subcribed by UI
     * **/
    override fun processResponse(response: List<SchoolData>) {
        response.apply {
            when (this[0]) {
                is NYCSchool -> {
                    updateSchoolData?.let { it(response as List<NYCSchool>) }
                    Log.d(SchoolListingUseCase::javaClass.toString(), "School list of size ${response.size} is now received")
                }
                else -> {
                    Log.d(SchoolListingUseCase::javaClass.toString(), "un expected result")
                }
            }
        }
    }

    fun getSchools(offsetNeeded: Number, updateData: (List<NYCSchool>) -> Unit) {
        updateSchoolData = updateData
        GlobalScope.async {
            SchoolRepository.getSchoolList(offsetNeeded)
        }
    }
}