package com.nyc.school.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.nyc.school.repository.datamodel.NYCSchool
import com.nyc.school.usecase.SchoolListingUseCase

class SchoolViewModel : ViewModel() {

    private var runningPage: Int = 0 // is offset ill implement paging if i get time to it
    private var mutableLiveData: MutableLiveData<List<NYCSchool>>? =
        MutableLiveData<List<NYCSchool>>()

    fun getSchools(): MutableLiveData<List<NYCSchool>> {
        return mutableLiveData!!
    }

    fun updateSchoolList(incomingData: List<NYCSchool>) {

        Log.d("SCHOOL LIVE DATA", "INCOMING ${incomingData.size}")

        incomingData.let {
            this@SchoolViewModel.mutableLiveData!!.value = incomingData
            mutableLiveData!!.value?.let {
                Log.d("SCHOOL LIVE DATA", "BEFORE ADDITION ${mutableLiveData!!.value!!.size}")
            }
            /*
            mutableLiveData!!.value?.apply {
                plus(incomingData)
                Log.d("SCHOOL LIVE DATA", "Now total ${mutableLiveData!!.value!!.size}")
            } ?: run { this@SchoolViewModel.mutableLiveData!!.value = incomingData }*/
        }
    }

    /**
     * next opr current page
     * **/
    fun getNextPage() {
        SchoolListingUseCase.getSchools(runningPage, ::updateSchoolList)
        runningPage += 1
    }
}