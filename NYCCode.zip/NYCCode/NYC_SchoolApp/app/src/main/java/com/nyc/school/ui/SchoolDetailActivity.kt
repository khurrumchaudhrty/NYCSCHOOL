package com.nyc.school.ui

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.nyc.school.R
import com.nyc.school.ui.adapters.SchoolAdapter
import com.nyc.school.viewmodel.SchoolDetailViewModel
import com.nyc.school.viewmodel.SchoolViewModel
import android.content.Intent
import com.nyc.school.databinding.ActivitySchoolDetailBinding
import com.nyc.school.repository.datamodel.NYCSchool


class SchoolDetailActivity : AppCompatActivity() {

    private var schoolSATViewModel: SchoolDetailViewModel? = null
    private var bundle: Bundle? = null
    private var binding: ActivitySchoolDetailBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySchoolDetailBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        bundle = this.intent.extras
    }

    override fun onPause() {
        super.onPause()
        schoolSATViewModel!!.getSATDetails().removeObservers(this)
    }

    override fun onResume() {
        super.onResume()
        schoolSATViewModel = ViewModelProviders.of(this).get(SchoolDetailViewModel::class.java)
        bundle?.let { bundle ->
            val school = bundle.getSerializable(UiConstants.SCHOOOL_BUNDLE_KEY) as NYCSchool

            school.let { school ->
                schoolSATViewModel!!.getSchoolSATData(school as NYCSchool)
                schoolSATViewModel!!.getSATDetails().observe(
                    this,
                    Observer() {
                        it.apply {
                            // update data to bindings
                            binding?.apply {
                                satMathScore.text = it.satMathAvgScore
                                    ?: resources.getString(R.string.not_available)
                                satReadingScore.text = it.satCriticalReadingAvgScore
                                    ?: resources.getString(R.string.not_available)
                                satWritingScore.text = it.satWritingAvgScore ?: resources.getString(
                                    R.string.not_available
                                )
                            }
                            Log.d("UI", "School SAT retrieved" + it.schoolName)
                        }
                    })
            }

            binding?.apply {
                schoolName.text = school.schoolName
                schoolPhone.text = school.phoneNumber
                schoolWebsite.text = school.website
                schoolFax.text = school.faxNumber
                schoolAddress.text = school.primaryAddressLine1
            }

        }
    }


}