package com.nyc.school.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.RecyclerView
import com.nyc.school.R
import com.nyc.school.databinding.ActivityMainBinding
import com.nyc.school.ui.adapters.SchoolAdapter
import com.nyc.school.usecase.SchoolListingUseCase
import com.nyc.school.usecase.UseCaseRegistry
import com.nyc.school.viewmodel.SchoolViewModel

class MainActivity : AppCompatActivity() {

    private var recyclerView: RecyclerView? = null
    private var schoolViewModel: SchoolViewModel? = null
    private var binding: ActivityMainBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        val toolbar = binding!!.toolbar
        setSupportActionBar(toolbar)
        toolbar.title = title
        title = resources.getString(R.string.list_header)

        recyclerView = binding!!.collectionLayout.itemList

        binding!!.loading.visibility = View.VISIBLE
        recyclerView!!.visibility = View.GONE

        recyclerView!!.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (!recyclerView.canScrollVertically(1) && dy > 0) {
                    schoolViewModel!!.getNextPage()
                } else if (!recyclerView.canScrollVertically(-1) && dy < 0) {
                    //scrolled to TOP
                }
            }
        })
    }

    override fun onPause() {
        super.onPause()
        schoolViewModel!!.getSchools().removeObservers(this)
    }

    override fun onResume() {
        super.onResume()
        schoolViewModel = ViewModelProviders.of(this).get(SchoolViewModel::class.java)
        schoolViewModel!!.getNextPage()
        schoolViewModel!!.getSchools().observe(
            this,
            Observer() {
                recyclerView!!.adapter = SchoolAdapter(it)
                recyclerView!!.adapter.apply {
                    this!!.notifyDataSetChanged()
                }

                if (it.size>1){
                    binding!!.loading.visibility = View.GONE
                    recyclerView!!.visibility = View.VISIBLE
                }
                Log.d("UI", "Total Schools in list shown" + it.size)
            })
    }

}