package com.nyc.school.usecase

import android.util.Log
import com.nyc.school.repository.datamodel.SchoolData

interface UseCase {
    fun processResponse(Object: List<SchoolData>)
}

object UseCaseRegistry {
    @Volatile internal var dataRegistery : Map<Any, UseCase> = mutableMapOf()

    fun add(useCase: UseCase, key: Any){
        dataRegistery = dataRegistery.plus(Pair(key, useCase))
        Log.d(UseCaseRegistry.javaClass.toString(), "$useCase registered")
    }

    fun notifyFor(response: List<SchoolData>) {
        Log.d(UseCaseRegistry.javaClass.toString(),  dataRegistery.size.toString() + " usecases registered")
        val useCase = dataRegistery[response[0]::class]
        useCase?.apply {
            processResponse(response)
            Log.d(this.javaClass.toString(), " UseCase Fired")
        } ?: Log.d(UseCaseRegistry.javaClass.toString(), "UseCase not registered")
    }
}