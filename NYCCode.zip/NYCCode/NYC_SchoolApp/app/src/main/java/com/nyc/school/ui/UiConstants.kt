package com.nyc.school.ui

object UiConstants{


    val SCHOOOL_BUNDLE_KEY: String = "SCHOOOL_BUNDLE_KEY"
}
