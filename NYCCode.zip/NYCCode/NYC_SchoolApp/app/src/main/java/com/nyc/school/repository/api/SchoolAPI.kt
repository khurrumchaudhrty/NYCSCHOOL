package com.nyc.school.repository.api

import com.nyc.school.repository.datamodel.NYCSchool
import com.nyc.school.repository.datamodel.SchoolSAT
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * both NYC school and SAT list are declared in this end point,
 * have not used the app token as it will only be
 * throteling for this excersize
 * **/
interface SchoolAPI {

    //List OF schools (not doing paging for now for the sake of example only)

    // forcing a cap for the sake of this example
    // to 300 true solution will include data persistence of already fetched data and fetching
    // smaller manageable chunks from API
    @GET("s3k6-pzi2.json")
    fun getSchoolList(
        @Query("\$limit") limit: Number? =10,
        @Query("\$offset") offset: Number? = 0
    ) : Call<List<NYCSchool>> ?


    // list of SAT results (filtering on dbn)
    // no need to apply limit here also for sake of excersize we will fetch repeatedly
    @GET("f9bf-2cp4.json")
    fun getSATScoreList(
        @Query("dbn") databaseBlockNumber: String,
        ) : Call <List<SchoolSAT>>?
}