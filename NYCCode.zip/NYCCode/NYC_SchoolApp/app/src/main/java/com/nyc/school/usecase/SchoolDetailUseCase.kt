package com.nyc.school.usecase

import android.util.Log
import com.nyc.school.repository.SchoolRepository
import com.nyc.school.repository.datamodel.SchoolData
import com.nyc.school.repository.datamodel.SchoolSAT
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async


/**
 * ideally it is a school domain and both should be a single use case im just writting the
 * multiple to show a different entry in registery for sake of this example
 * **/
object SchoolDetailUseCase: UseCase {

    private var updateSchoolDetail: ((SchoolSAT) -> Unit)? = null

    init {
        UseCaseRegistry.add(this, SchoolSAT::class)
    }

    override fun processResponse(response: List<SchoolData>) {
        response.apply {
            when (this[0]) {
                is SchoolSAT -> {
                    updateSchoolDetail?.let { it(response[0] as SchoolSAT) }
                    Log.d(SchoolDetailUseCase::javaClass.toString(), "SAT result is in yay")
                }
                else -> {
                    Log.d(SchoolDetailUseCase::javaClass.toString(), "un expected result")
                }
            }
        }
    }

    fun getSAT(dbnNumberForSchool: String, futureSchoolDetail: (SchoolSAT) -> Unit) {
        updateSchoolDetail = futureSchoolDetail
        GlobalScope.async {
            SchoolRepository.getSchoolSAT(dbnNumberForSchool)
        }
    }

}